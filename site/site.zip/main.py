import sqlite3
from typing import Annotated, Optional

import uvicorn
from fastapi import FastAPI, Form, Request, Response, Depends, Cookie
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi_users.authentication import CookieTransport
from starlette.responses import JSONResponse

from utils.JWT import get_current_user
from data import db_session
from data.users import User
from utils.JWT import *
from requests import request as rqe
cookie_transport = CookieTransport(cookie_max_age=36000)
app = FastAPI()
app.mount("/front", StaticFiles, "front")
con = sqlite3.connect("users_db", check_same_thread=False)
cur = con.cursor()
db_session.global_init("db/users_db")
templates = Jinja2Templates(directory="templates")

def bot_call(telegram):
    data = 123
    return data


@app.get("/registration")
def register(request: Request):
    return templates.TemplateResponse("registration.html", {"request": request})


@app.post("/registration")
def registration(phone=Form(), telegram=Form(), name=Form(), group=Form()):
    db_sess = db_session.create_session()
    data = db_sess.query(User).filter(User.telegram == telegram).first()
    if not data:
        user = User(
            phone=phone,
            telegram=telegram,
            name=name,
            group=group
        )
        db_sess.add(user)
        db_sess.commit()
        db_sess.close()
        return True
    return "Такой пользователь уже существует"

@app.get("/")
def log_in(request: Request, response: Response):
    return templates.TemplateResponse("log_in.html", {"request": request, "response": response})

@app.get("/code")
def code(request: Request, response: Response, telegram):
    data = bot_call(telegram)
    global tlg, dt
    tlg = telegram
    dt = data
    return templates.TemplateResponse("code.html", {"request": request, "response": response})

@app.post("/index")
def success(response: Response, request: Request, code=Form()):
    data = dt
    telegram = tlg
    if data == code:
        pass
    print(telegram)
    access_token = create_access_token({"sub": str(telegram)})
    response.set_cookie(key="users_access_token", value=access_token, httponly=True)
    return templates.TemplateResponse("success.html", {"request": request, "response": response})


@app.get("/index")
async def get_me(request: Request, response: Response):
    user_data = get_current_user(tlg, get_token(request))
    if user_data:
        name = str(user_data[0]).split(sep=", ")
        return templates.TemplateResponse("index.html",
                                          {"request": request, "resopse": response, "name": name[0], "telegram": name[1], "group": name[2],
                                           "points": name[3]})


@app.post("/logout")
async def logout_user(response: Response):
    response.delete_cookie(key="users_access_token")
    return {'message': 'Пользователь успешно вышел из системы'}




if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)